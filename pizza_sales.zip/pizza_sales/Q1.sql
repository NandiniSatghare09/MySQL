# Total Number of orders placed.
SELECT COUNT(order_id) as total_orders FROM	 orders;